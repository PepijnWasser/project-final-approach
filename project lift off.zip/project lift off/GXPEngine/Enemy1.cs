﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class Enemy1 : AnimationSprite
    {
        Platform _platform;
        Boolean _onPlatform = true;
        Boolean _previousOnPlatform;
        float _platformSpeed;
        int _levelColor;

        readonly int _timeBetweenFrames = 6;
        int _step;

        float _speed = (float)0.5;
        int _rotated = 0;
        int _walkFrame = 1;

        public Enemy1(Platform platform, float platformspeed, int levelcolor) : base("Enemy1_spritesheet.png", 8, 4)
        {
            _levelColor = levelcolor;
            _platformSpeed = platformspeed;
            this.SetOrigin(width / 2, height);
            _platform = platform;
            this.SetXY(_platform.x, _platform.y - _platform.height / 2 + (float)0.1);
        }

        void Update()
        {
            _onPlatform = false;
            Fall();
            Walking();
            _previousOnPlatform = _onPlatform;
            Delete();
        }

        //makes the enemy fall as fast as the platform
        void Fall()
        {
            this.y = this.y + _platformSpeed;
        }

        //walking control
        void Walking()
        {
            WalkAnimation();
            if (this.x + _speed < _platform.x + 0.5 * _platform.width && this.x + _speed > _platform.x - 0.5 * _platform.width)
            {
                this.x = this.x + _speed;
            }
            else
            {             
                _speed = _speed * -1;
                if(_rotated == 1)
                {
                    this.Mirror(false, false);
                    _rotated = 0;
                }
                else if(_rotated == 0)
                {
                    this.Mirror(true, false);
                    _rotated = 1;
                }
            }
        }

        //animation when moving
        void WalkAnimation()
        {
            _step = _step + 1;
            if (_step > _timeBetweenFrames)
            {
                _step = 0;
                _walkFrame = _walkFrame + 1;
                if(_levelColor == 1)
                {
                    if (_walkFrame > 6)
                    {
                        _walkFrame = 1;
                        SetFrame(1);
                    }
                }
                if (_levelColor == 2)
                {
                    if (_walkFrame > 12 || _walkFrame < 7)
                    {
                        _walkFrame = 7;
                        SetFrame(7);
                    }
                }
                if (_levelColor == 3)
                {
                    if (_walkFrame > 18 || _walkFrame < 15)
                    {
                        _walkFrame = 15;
                        SetFrame(15);
                    }
                }
                if (_levelColor == 4)
                {
                    if (_walkFrame > 24 || _walkFrame < 23)
                    {
                        _walkFrame = 23;
                        SetFrame(23);
                    }
                }
                NextFrame();
            }
        }

        //deletes enemy if it is offscreen
        void Delete()
        {
            if(this.y > game.height)
            {
                this.LateDestroy();
            }
        }

        void OnCollision(GameObject other)
        {
            if (other is Platform)
            {
                _onPlatform = true;
            }
        }
    }
}
