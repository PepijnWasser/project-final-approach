﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class ForeGround : AnimationSprite
    {
        public ForeGround() : base("foreground.png", 4, 1)
        {

        }

        //change foreground color
        public void UpdateFrame()
        {
            NextFrame();
        }
    }
}
