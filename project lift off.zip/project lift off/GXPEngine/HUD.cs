﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace GXPEngine
{
    class HUD : Canvas
    {
        string _amountOfPlatforms;

        readonly Font font = new Font(new FontFamily("Verdana"), 20);

        public HUD(int amountofplatforms) : base(600, 800)
        {
            _amountOfPlatforms = amountofplatforms.ToString();
        }         

        void Update()
        {
            graphics.Clear(Color.Empty);
            graphics.DrawString("SCORE: " + _amountOfPlatforms, font, Brushes.White, 10, 10);
        }
    }
}
