﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class Shield : Sprite
    {
        float _platformSpeed;

        Platform _platform;
        
        public Shield(Platform platform, float platformspeed) : base("shield.png")
        {
            this.SetOrigin(width / 2, height);
            _platform = platform;
            this.SetScaleXY((float)1, (float)1);
            this.SetXY(_platform.x, _platform.y - _platform.height / 2);
            _platformSpeed = platformspeed;
        }

        void Update()
        {
            this.y = this.y + _platformSpeed;
        }
    }
}
