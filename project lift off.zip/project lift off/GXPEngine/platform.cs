﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    public class Platform : AnimationSprite
    {
        
        int _randomX;
        public float _platformspeed;
        int _levelcolor;
        public Platform(int randomX, float platformspeed, int levelcolor, Boolean startplatform) : base("platforms.png", 4, 1)
        {
            this.SetScaleXY((float)1, (float)1);
            _randomX = randomX;
            _platformspeed = platformspeed;
            _levelcolor = levelcolor;
            if (startplatform == true)
            {
                this.SetXY(game.width / 2, 100);
            }
            else
            {
                this.x = randomX;
                this.y = -this.height / 2;
            }
            SetOrigin(width / 2, height / 2);
            SetColor();
        }

        //moves the platform down
        void Update()
        {
            this.y = this.y + _platformspeed;
        }

        //destroys platform if it is offscreen
        void destroy()
        {
            if(this.y - this.height / 2 < game.height)
            {
                this.LateDestroy();
            }
        }

        //sets the color of the platform
        void SetColor()
        {
            if (_levelcolor == 1) 
            { 

            }
            if (_levelcolor == 2)
            {
                NextFrame();
            }
            if (_levelcolor == 3)
            {
                NextFrame();
                NextFrame();
            }
            if (_levelcolor == 4)
            {
                NextFrame();
                NextFrame();
                NextFrame();
            }
        }
    }
}
