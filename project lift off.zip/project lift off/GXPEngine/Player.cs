﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    public class Player : AnimationSprite
    {
        float dy;

        Boolean shielded;
        int HP = 1;

        int walkFrame;
        int flyFrame;
        int idleFrame;
        int timeBetweenFrames = 3;
        int step;
        
        Boolean onPlatform;
        Boolean lastOnPlatform;

        Platform thisPlatform;

        readonly Sound _jumpSound;
        readonly Sound _surviveSound;
        readonly Sound _deathSound;
        readonly Sound _pickup;

        public Player() : base("Character_spritesheet.png", 24, 1)
        {
            _jumpSound = new Sound("jump_sound.wav", false, false);
            _surviveSound = new Sound("enemy_survive.wav", false, false);
            _deathSound = new Sound("death_sound.wav", false, false);
            _pickup = new Sound("pickup.wav",false,false);
            SetOrigin(width / 2, height);
            this.x = game.width/2;
            this.y = 0;
            this.SetScaleXY(1, 1);
        }

        void Update()
        {           
            Controls();
            Gravity();
            OnPlatform();
            Boundries();
            lastOnPlatform = onPlatform;
        }

        void OnPlatform()
        {
            if(lastOnPlatform == true)
            {
                this.y = thisPlatform.y - thisPlatform.height / 2;
            }
        }

        void Controls()
        {
            if (Input.GetKey(Key.A))
            {
                this.Mirror(false, false);
                this.Move(-4, 0);
                if (dy == 0 || dy == 0.3)
                {
                    walkanimation();
                }
            }
            if (Input.GetKey(Key.D))
            {
                this.Mirror(true, false);
                this.Move(4, 0);
                if (dy == 0 || dy == 0.3)
                {
                    walkanimation();
                }
            }
            Jumping();
            if(Input.GetKey(Key.W) == false && Input.GetKey(Key.A) == false && Input.GetKey(Key.S) == false && Input.GetKey(Key.D) == false && Input.GetKey(Key.SPACE) == false)
            {
                Idleanimation();
            }
        }

        void flyAnimation()
        {
            if(dy > (float)0.3 || dy < 0)
            {
                step = step + 1;
                if (step > timeBetweenFrames)
                {
                    step = 0;
                    flyFrame = flyFrame + 1;
                    if (flyFrame > 24 || flyFrame < 16)
                    {
                        flyFrame = 16;
                        SetFrame(16);
                    }
                    NextFrame();
                }
            }         
        }

        void walkanimation()
        {
            step = step + 1;
            if (step > timeBetweenFrames)
            {
                step = 0;
                walkFrame = walkFrame + 1;
                if (walkFrame > 15 || walkFrame < 10)
                {
                    walkFrame = 10;
                    SetFrame(10);
                }
                NextFrame();
            }
        }     

        void Idleanimation()
        {
            step = step + 1;
            if (step > timeBetweenFrames)
            {
                step = 0;
                idleFrame = idleFrame + 1;
                if (idleFrame > 9)
                {
                    idleFrame = 0;
                    SetFrame(0);
                }
                NextFrame();
            }
        }

        void Jumping()
        {
            if (Input.GetKey(Key.SPACE) == true && (dy == thisPlatform._platformspeed || ((onPlatform == false && lastOnPlatform == true) || onPlatform == true)))
            {
                _jumpSound.Play();
                dy = -12;
            }                                                                                                   
            flyAnimation();
        }

        void Boundries()
        {
            if (this.x > (game.width))
            {
                this.x = (game.width);
            }
            if (this.x < 25)
            {
                this.x = 25;
            }
            if (this.y > (game.height))
            {
                this.y = (game.height);
                HP = 0;
            }
            if (this.y < 25)
            {
                this.y = 25;
                dy = 0;
            }
        }

        void Gravity()
        {
            dy = dy + (float)0.3;
            if(dy > 12)
            {
                dy = 12;
            }
            this.Move(0, dy);
        }

        void OnCollision(GameObject other)
        {
            if(other is Platform)
            {
                Platform _platform = other as Platform;
                //above platform
                if (this.y > _platform.y - _platform.height && this.y < _platform.y - _platform.height / 4 && this.x + this.width / 2 > _platform.x - _platform.width / 2 && this.x - this.width / 2 < _platform.x + _platform.width / 2)
                {
                    this.y = _platform.y - _platform.height / 2;
                    dy = _platform._platformspeed;
                    onPlatform = true;
                    thisPlatform = _platform;
                }
                else
                {
                    onPlatform = false;
                }   
            }
            else
            {
                onPlatform = false;
            }

            if(other is Shield)
            {
                Shield _shield = other as Shield;
                shielded = true;
                _pickup.Play();
                _shield.LateDestroy();
            }

            if (other is Enemy1)
            {
               Enemy1 _enemy1 = other as Enemy1;
               _enemy1.LateDestroy();
                if(shielded == true)
                {
                    shielded = false;
                    _surviveSound.Play();
                }
                else
                {
                    HP = HP - 1;
                }
            }
        }      
        public Boolean IsGameOver()
        {
            if(HP > 0)
            {
                return false;
            }
            else
            {
                _deathSound.Play();
                return true;
            }
        }
    }
}


