﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace GXPEngine
{
    public class Level : Canvas
    {
        int _levelMillisecondCounter;
        int _levelSecondCounter;
        int _platformMillisecondCounter = 3500;

        int randondomPlatformX1;
        int randomPlatformX2;

        int levelColor = 1;
      
        public int amountOfPlatforms;
        int _amountOfPlatformsOld;
        float _platformSpeed = (float)0.6;

        Background space = new Background();
        ForeGround foreGround = new ForeGround();

        Player _player;

        HUD hud;

        SoundChannel _musicChannel;
        Sound _music;

        public Level() : base(600, 1080, false)
        {
            _music = new Sound("music.wav", true, false);
            _musicChannel = _music.Play();

            AddChild(space);
            AddChild(foreGround);

            Player player = new Player();
            AddChild(player);
            _player = player;

            Platform platform = new Platform(game.width / 2, _platformSpeed, levelColor, true);
            AddChild(platform);       
        }

        void Update()
        {
            BackgroundControl();
            Platforms();
            UpdateHUD();
            _amountOfPlatformsOld = amountOfPlatforms;
        }

        void BackgroundControl()
        {
            _levelMillisecondCounter += Time.deltaTime;
            if (_levelMillisecondCounter >= 1000)
            {
                _levelMillisecondCounter = 0;
                _levelSecondCounter = _levelSecondCounter + 1;
            }
            if (_levelSecondCounter == 60)
            {
                levelColor = levelColor + 1;
                if (levelColor > 4)
                {
                    levelColor = 1;
                }
                space.UpdateFrame();
                foreGround.UpdateFrame();
                _levelSecondCounter = 0;
            }
        }
        void Platforms()
        {
            _platformMillisecondCounter += Time.deltaTime;
            if (_platformMillisecondCounter >= 6333 / (_platformSpeed/0.6))
            {
                _platformMillisecondCounter = 0;
                SetSpeed();
                spawnPlatform();
                amountOfPlatforms = amountOfPlatforms + 1;
            }
        }

        void spawnPlatform()
        {
            randondomPlatformX1 = Utils.Random(0, game.width / 2);
            randomPlatformX2 = Utils.Random(game.width / 2, game.width);

            Platform platform = new Platform(randondomPlatformX1, _platformSpeed, levelColor, false);
            AddChild(platform);

            Powerups(platform);
            Enemies(platform);

            platform = new Platform(randomPlatformX2, _platformSpeed, levelColor, false);
            AddChild(platform);

            Powerups(platform);
            Enemies(platform);
        }

        void SetSpeed()
        {
            _platformSpeed = _platformSpeed + (float)0.05;
            if (_platformSpeed > (float)5)
            {
                _platformSpeed = (float)5;
            }
        }

        void Powerups(Platform _platform)
        {
            int randomPowerUp = Utils.Random(0, 10);
            if (randomPowerUp == 1)
            {
                Shield shield = new Shield(_platform, _platformSpeed);
                AddChild(shield);
            }
        }

        void Enemies(Platform _platform)
        {
            int randomEnemy = Utils.Random(0, 3);
            if (randomEnemy == 1)
            {
                Enemy1 enemy1 = new Enemy1(_platform, _platformSpeed, levelColor);
                AddChild(enemy1);
            }
        }     

        void UpdateHUD()
        {
            if (_amountOfPlatformsOld != amountOfPlatforms)
            {
                if(hud != null){
                    hud.LateDestroy();
                    }
                hud = new HUD(amountOfPlatforms);
                AddChild(hud);
            }
        }

        public bool ChangeScreen()
        {
            if(_player.IsGameOver())
            {
                _musicChannel.Stop();
                return true;
            }
            else
            {
                return false;
            }
        }      
    }
}