﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class Startscreen : AnimationSprite
    {
        int _timeBetweenFrames = 6;
        int _step;

        Sound _frog_Sound;

        public Startscreen() : base("startscreen" + ".png", 8, 1)
        {
            this.SetXY(0, -5);
            _frog_Sound = new Sound("frog_sound.wav", false, false);
        }

        void Update()
        {
            Fading();
        }

        //screen fade
        void Fading()
        {
            _step = _step + 1;
            if (_step > _timeBetweenFrames)
            {
                _step = 0;
                NextFrame();
            }
        }

        /// ///////////////////////////////////////////////////////////////////////
        /// if A is pressed, return true
        /// ///////////////////////////////////////////////////////////////////////
        public bool ChangeScreen()
        {
            if (Input.GetKey(Key.E))
            {
                _frog_Sound.Play();
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
