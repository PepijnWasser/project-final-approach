﻿using System;
using GXPEngine;

public enum Screen
{
    startscreen,
    game,
    endScreen
}

class Screens : Canvas
{
    Level level;
    EndScreen endScreen;
    Startscreen startscreen;

    Screen screen = Screen.startscreen;

    public Screens() : base(1920, 1080)
    {
        ResetScreens();
    }

    void ResetScreens()
    {
        DestroyScreens();
        MakeNewScreen();
    }

    void Update()
    {
        TestChangeScreen();
    }

    /// ///////////////////////////////////////////////////////////////////////
    /// Check if the screen needs to change
    /// ///////////////////////////////////////////////////////////////////////
    void TestChangeScreen()
    {
        if (level != null)
        {
            if (level.ChangeScreen())       
            {
                screen = Screen.endScreen;
                ResetScreens();
            }
        }
        if (endScreen != null)
        {
            if (endScreen.ChangeScreen())  
            {
                screen = Screen.startscreen;
                ResetScreens();
            }
        }
        if (startscreen != null)
        {
            if (startscreen.ChangeScreen())
            {
                screen = Screen.game;
                ResetScreens();
            }
        }
    }

    /// ///////////////////////////////////////////////////////////////////////
    /// if there is a active screen destroy it
    /// ///////////////////////////////////////////////////////////////////////
    void DestroyScreens()
    {
        if (endScreen != null)
        {
            endScreen.LateDestroy();
            endScreen = null;
        }
        if (level != null)
        {
            level.LateDestroy();
            level = null;
        }
        if (startscreen != null)
        {
            startscreen.LateDestroy();
            startscreen = null;
        }
    }
    /// ///////////////////////////////////////////////////////////////////////
    /// make the correct screen
    /// ///////////////////////////////////////////////////////////////////////
    void MakeNewScreen()
    {
        if (screen == Screen.game)
        {
            level = new Level();
            AddChild(level); 
             
        }
        if (screen == Screen.startscreen)
        {
           startscreen = new Startscreen();
           AddChild(startscreen);
        }

    }
}