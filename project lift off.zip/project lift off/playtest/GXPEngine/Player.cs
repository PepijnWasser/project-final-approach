﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    public class Player : AnimationSprite
    {
        float dy;
        Boolean wasKeyPressed;
        float jumpPower;
        Boolean shielded;
        int walkframe;
        int flyframe;
        int timeBetweenFrames = 100;
        int step;
        int hp = 1;
        Boolean onPlatform;
        Boolean lastOnPlatform;

        public Player() : base("Character_spritesheet.png", 6, 1)
        {
            SetOrigin(width / 2, height);
            this.x = 200;
            this.y = 50;
            this.SetScaleXY(1, 1);
        }

        void Update()
        {
            Controls();
            Gravity();
            Boundries();
            Console.WriteLine(dy);

        }

        void Controls()
        {
            if (Input.GetKey(Key.A))
            {
                this.Move(-4, 0);
                if (dy == 0 || dy == 0.3)
                {
                    walkanimation();
                }
            }
            if (Input.GetKey(Key.D))
            {
                this.Move(4, 0);
                walkanimation();
            }
            Jumping();
        }

        void flyAnimation()
        {
            if(dy > (float)0.3 || dy < 0)
            {
                step = step + 1;
                if (step > timeBetweenFrames)
                {
                    flyframe = flyframe + 1;
                    if (flyframe >= 29)
                    {
                        flyframe = 19;
                        SetFrame(19);
                    }
                    NextFrame();
                }
            }         
        }

        void walkanimation()
        {
            if(dy == 0 || dy == (float)0.3)
            {
                step = step + 1;
                if (step > timeBetweenFrames)
                {
                    walkframe = walkframe + 1;
                    if (walkframe >= 5)
                    {
                        walkframe = 1;
                        SetFrame(1);
                    }
                    NextFrame();
                }
            }     
        }

        void Jumping()
        {
            if (Input.GetKey(Key.SPACE) == false && wasKeyPressed == true && (dy == 0 || dy == 0.3 || dy == 0.6 || dy == 0.9))
            {
                dy = -12;
            }                                                                                                   
            
            if (Input.GetKey(Key.SPACE))
            {
                wasKeyPressed = true;
              ///  jumpPower = jumpPower + (float)0.5;
              //  if(jumpPower > 12)
             //   {
             //         jumpPower = 12;
            //    }
            }
            else
            {
                wasKeyPressed = false;
                jumpPower = 0;
            }
           // flyAnimation();
        }

        void Boundries()
        {
            if (this.x > (game.width))
            {
                this.x = (game.width);
            }
            if (this.x < 25)
            {
                this.x = 25;
            }
            if (this.y > (game.height))
            {
                this.y = (game.height);
                dy = 0;
            }
            if (this.y < 25)
            {
                this.y = 25;
                dy = 0;
            }
        }

        void Gravity()
        {
            dy = dy + (float)0.3;
            if(dy > 12)
            {
                dy = 12;
            }
            this.Move(0, dy);
        }

        void OnCollision(GameObject other)
        {
            if(other is Platform)
            {
                Platform _platform = other as Platform;
                //left side
                if (this.x + this.width / 2 > _platform.x - _platform.width / 2 && this.x + this.width / 2 < _platform.x && this.y > _platform.y - _platform.height / 2 + 20 && this.y - this.height < _platform.y + _platform.height / 2 - 20)
                {
                    this.x = _platform.x - _platform.width / 2 - this.width / 2;
                }
                //right side
                if (this.x - this.width / 2 < _platform.x + _platform.width / 2 && this.x - this.width / 2 > _platform.x && this.y > _platform.y - _platform.height / 2 + 20 && this.y - this.height < _platform.y + _platform.height / 2 - 20)
                {
                    this.x = _platform.x + _platform.width / 2 + this.width / 2;
                }
                //above platform
                if (this.y > _platform.y - _platform.height && this.y < _platform.y && this.x + this.width / 2 > _platform.x - _platform.width / 2 && this.x - this.width / 2 < _platform.x + _platform.width / 2)
                {
                    this.y = _platform.y - _platform.height / 2;
                    dy = 0;                   
                } 
                //below platform
                if(this.y - this.height < _platform.y + _platform.height / 2 && this.y - this.height > _platform.y && this.x + this.width / 2 > _platform.x - _platform.width / 2 && this.x - this.width / 2 < _platform.x + _platform.width / 2)              
                {
                    this.y = _platform.y + _platform.height / 2 + this.height;
                    dy = (float)0.5;
                }                
            }
            if(other is Shield)
            {
                Shield _shield = other as Shield;
                shielded = true;
                _shield.LateDestroy();
            }
            if (other is Enemy1)
            {
               Enemy1 _enemy1 = other as Enemy1;
               _enemy1.LateDestroy();
                if(shielded == true)
                {
                    shielded = false;
                }
                else
                {
                    hp = hp - 1;
                }
            }
        }      
        public Boolean IsGameOver()
        {
            if(hp > 0)
            {
                return false;

            }
            else
            {
                return true;
            }
        }
    }
}


