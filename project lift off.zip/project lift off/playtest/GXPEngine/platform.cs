﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    public class Platform : Sprite
    {
        int _randomX;
        public Platform(int randomX) : base("grass.png")
        {
            _randomX = randomX;
            SetOrigin(width / 2, height / 2);
            this.x = randomX;
            this.y = -this.height / 2;
        }

        void Update()
        {
            this.y = this.y + (float)0.6;
        }
    }
}
