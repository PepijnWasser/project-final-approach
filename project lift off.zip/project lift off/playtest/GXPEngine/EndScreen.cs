﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class EndScreen : Canvas
    {
        public EndScreen() : base(1920, 1080, false)
        {

        }

        /// ///////////////////////////////////////////////////////////////////////
        /// if R is pressed, return true
        /// ///////////////////////////////////////////////////////////////////////
        public bool ChangeScreen()
        {
            if (Input.GetKey(Key.R))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}