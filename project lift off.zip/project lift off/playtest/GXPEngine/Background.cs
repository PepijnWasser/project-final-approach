﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class Background :AnimationSprite
    {
        public Background() : base("background.png", 4, 1)
        {
            this.SetXY(30, -15);
            this.SetScaleXY((float)1.05, (float)1.05);
        }

        public void UpdateFrame()
        {
                NextFrame();
        }
    }
}
