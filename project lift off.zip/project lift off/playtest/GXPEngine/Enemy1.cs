﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class Enemy1 : Sprite
    {
        Platform _platform;
        public Enemy1(Platform platform) : base("square.png")
        {
            this.SetOrigin(width / 2, height);
            _platform = platform;
            this.SetXY(_platform.x, _platform.y - _platform.height / 2);
        }

        void Update()
        {
            this.y = this.y + (float)0.6;
        }
    }
}
