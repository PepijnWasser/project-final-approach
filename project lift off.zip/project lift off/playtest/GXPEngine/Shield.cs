﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class Shield : Sprite
    {
        Platform _platform;

        public Shield(Platform platform) : base("shield.png")
        {
            this.SetOrigin(width / 2, height);
            _platform = platform;
            this.SetScaleXY((float)0.1, (float)0.1);
            this.SetXY(_platform.x, _platform.y - _platform.height / 2);
        }

        void Update()
        {
            this.y = this.y + (float)0.6;
        }
    }
}
