﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace GXPEngine
{
    public class Level : Canvas
    {
        int _levelMillisecondCounter;
        int _levelSecondCounter;
        int _platformMillisecondCounter;
        int _platformSecondCounter;
        int randomX1;
        int randomX2;

        Player _player;

        Background space = new Background();
        ForeGround foreGround = new ForeGround();

        public Level() : base(600, 1080, false)
        {
           
            AddChild(space);          

            AddChild(foreGround);

            Player player = new Player();
            AddChild(player);
            _player = player;
        }

        void Update()
        {
            BackgroundControl();
            Platforms();
        }

        void BackgroundControl()
        {
            _levelMillisecondCounter += Time.deltaTime;
            if (_levelMillisecondCounter >= 1000)
            {
                _levelMillisecondCounter = 0;
                _levelSecondCounter = _levelSecondCounter + 1;
            }
            if (_levelSecondCounter == 60)
            {
                space.UpdateFrame();
                foreGround.UpdateFrame();
                _levelSecondCounter = 0;
            }
        }

    
        void Platforms()
        {
            _platformMillisecondCounter += Time.deltaTime;
            if (_platformMillisecondCounter >= 1000)
            {
                _platformMillisecondCounter = 0;
                _platformSecondCounter = _platformSecondCounter + 1;
            }
            if (_platformSecondCounter == 6)
            {
                spawnPlatform();
                _platformSecondCounter = 0;
            }
        }
        void spawnPlatform()
        {
            randomX1 = Utils.Random(0, game.width / 2);
            randomX2 = Utils.Random(game.width / 2, game.width);

            Platform platform = new Platform(randomX1);
            AddChild(platform);
            platform = new Platform(randomX2);
            AddChild(platform);

            Powerups(platform);
            Enemies(platform);
            
        }

        void Powerups(Platform _platform)
        {
            int randomPowerUp = Utils.Random(0, 4);
            if (randomPowerUp == 1)
            {
                Shield shield = new Shield(_platform);
                AddChild(shield);
            }
        }
        void Enemies(Platform _platform)
        {
            int randomEnemy = Utils.Random(0, 8);
            if (randomEnemy == 1)
            {
                Enemy1 enemy1 = new Enemy1(_platform);
                AddChild(enemy1);
            }
        }

        public bool ChangeScreen()
        {
            if(_player.IsGameOver())
            {
                return true;
            }
            else
            {
                return false;
            }
        }      
    }
}