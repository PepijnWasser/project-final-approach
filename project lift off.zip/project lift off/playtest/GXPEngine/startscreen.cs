﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{
    class Startscreen : Sprite
    {
        public Startscreen() : base("startscreen" + ".png")
        {

        }

        /// ///////////////////////////////////////////////////////////////////////
        /// if A is pressed, return true
        /// ///////////////////////////////////////////////////////////////////////
        public bool ChangeScreen()
        {
            if (Input.GetKey(Key.A))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
